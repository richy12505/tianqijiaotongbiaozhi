function varargout = Traffic_Iden(varargin)
% TRAFFIC_IDEN MATLAB code for Traffic_Iden.fig
%      TRAFFIC_IDEN, by itself, creates a new TRAFFIC_IDEN or raises the existing
%      singleton*.
%
%      H = TRAFFIC_IDEN returns the handle to a new TRAFFIC_IDEN or the handle to
%      the existing singleton*.
%
%      TRAFFIC_IDEN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TRAFFIC_IDEN.M with the given input arguments.
%
%      TRAFFIC_IDEN('Property','Value',...) creates a new TRAFFIC_IDEN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Traffic_Iden_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Traffic_Iden_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Traffic_Iden

% Last Modified by GUIDE v2.5 12-Mar-2021 16:01:53

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @Traffic_Iden_OpeningFcn, ...
    'gui_OutputFcn',  @Traffic_Iden_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
    
end
% End initialization code - DO NOT EDIT


% --- Executes just before Traffic_Iden is made visible.
function Traffic_Iden_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Traffic_Iden (see VARARGIN)

% Choose default command line output for Traffic_Iden
set(gcf,'name','��ϵ΢��:matlab1998  ');
handles.output = hObject;
handles.cd0 = cd;
handles.Color = 0;
handles.I = [];

axes(handles.axes1);
set(gca,'Xtick',[]);
set(gca,'Ytick',[]);
box on;

axes(handles.axes2);
set(gca,'Xtick',[]);
set(gca,'Ytick',[]);
box on;

axes(handles.axes3);
set(gca,'Xtick',[]);
set(gca,'Ytick',[]);
box on;

axes(handles.axes4);
set(gca,'Xtick',[]);
set(gca,'Ytick',[]);
box on;
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Traffic_Iden wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Traffic_Iden_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton3


% --- Executes on button press in radiobutton4.
function radiobutton4_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton4


% --- Executes on button press in radiobutton5.
function radiobutton5_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton5


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%%   ��ͼ
[filename, cd1] = uigetfile( ...
    {'*.tif;*.TIF;*.JPG;*.jpg;*.bmp;*.BMP;*.jpeg;*.JPEG;','Image file';...
    '*.*', 'All file (*.*)'},'Pick an Image');
axes(handles.axes1);
cla;
axes(handles.axes2);
cla;
axes(handles.axes3);
cla;
axes(handles.axes4);
cla;
axes(handles.axes5);
cla;
axes(handles.axes6);
cla;
axes(handles.axes7);
cla;
axes(handles.axes8);
cla;
if filename
    
    cd(cd1);
    d = imread(filename);
    cd(handles.cd0);
    handles.I = d;
    axes(handles.axes5);
    imshow(d);
    title('���������Ľ�ͨ��־ͼ��')
    imwrite(d,'��ͨ��ȥ���������ͼ��.jpg')
    handles.filename = filename;
    
    box on;
    
end
save d

handles.Color = 0;
cd(handles.cd0);
set(handles.text2,'string','');
guidata(hObject, handles);
set(handles.text4,'string','��ȡ����ͼ�����')

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% ��ȡ��־
% ������ɫ����
str1=sprintf('����˼·\n\n');
str4=sprintf('           ����ʱ��ִ٣������������ϵ��ʦ΢��:matlab1998  \n');
string=[str1 str4];
msgbox(string,'��ܰ��ʾ','none');
return
axes(handles.axes2); %��������ϵ

imshow(DI);
title('�Ҷȴ���')
set(handles.text4,'string','�Ҷ�ͼ����')
pause(3)
axes(handles.axes3);

imshow(GI);
title('��ֵ����λ')
set(handles.text4,'string','������λ���')
handles.GI = GI;

guidata(hObject, handles);


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% �ָ��־
str1=sprintf('����˼·\n\n');
str4=sprintf('           ����ʱ��ִ٣������������ϵ��ʦ΢��:matlab1998  \n');
string=[str1 str4];
msgbox(string,'��ܰ��ʾ','none');
return

for i = 1:Num
    
    S(i) = sum(sum(L == i));
    
end

[S,id] = sort(S,'descend');

Ran = zeros(Num,4); % ��Χ

Fig = zeros(1,Num); % ������

for i = 1:Num
    
    [ix,iy] = find(L == id(i));
    
    Ran(i,:) = [min(ix),max(ix),min(iy),max(iy)]; % ÿһ������ķ�Χ
    
end


for i = 1:Num
    
    Fig(i) = max(Ran(i,2)-Ran(i,1),Ran(i,4)-Ran(i,3))/min(Ran(i,2)-Ran(i,1),Ran(i,4)-Ran(i,3));
    
end

in = 0;

for i = 1:Num
    
    if Fig(i) < 1.5 % �������ǽӽ�1�� ���Բ���̫����
        
        in = i;
        
        break;
        
    end
    
end

if in == 0
    
    in = 1; % �������������϶��������һ���� ��ʱ��϶����и��ŵ�
    
end

axes(handles.axes3);

axes(handles.axes4);
imshow(II);
title('��ͨ��־��ȡ')
set(handles.text4,'string','�ɹ���ȡ����ͨ��־')
% imwrite(II,'5.png','png')
handles.Divice = II;
guidata(hObject, handles);



% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% �����ť�ر�����
close all;
clear;
clc;


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% ʶ��ť
set(handles.text4,'string','��ͨ��־ʶ���С�����')
str1=sprintf('����˼·\n\n');
str4=sprintf('           ����ʱ��ִ٣������������ϵ��ʦ΢��:matlab1998 \n');
string=[str1 str4];
msgbox(string,'��ܰ��ʾ','none');
return
set(handles.text2,'string',str);
set(handles.text4,'string','ʶ����ɣ�')

% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
str1=sprintf('����˼·\n\n');
str4=sprintf('           ����ʱ��ִ٣������������ϵ��ʦ΢��:matlab1998 \n');
string=[str1 str4];
msgbox(string,'��ܰ��ʾ','none');
return
%--------------------����ͼ��İ�ԭɫ����-----------------------------------

%���������
t=1-w_1*dark_ori/A;
t=max(min(t,1),0);
%figure;
axes(handles.axes7)
imshow(t);
title('ԭʼ͸����ͼ');
set(handles.text4,'string','ԭʼ͸����ͼ��ȡ�ɹ�')

%------------�Ľ�͸����----------------------------------------------------
dark_ori1=min(min(min(I(:,:,:))));
dark_max1=zeros(w,h);
for i=1:h
    for j=1:w
        dark_max1(i,j)=min(I(i,j,:));
    end
end
dark_max=max(max(dark_max1(:,:)));
t1=ones(h,w);
t2=ones(h,w);
for i=1:h
    for j=1:w
        t1(i,j)=(dark_max-dark_ori1)*(A-min(I(i,j,:)));
        t2(i,j)=(dark_max-dark_ori1)*A-(min(I(i,j,:))-dark_ori1)*min(I(i,j,:));
        t(i,j)=t1(i,j)/t2(i,j);
    end
end
t=max(min(t,1),0);
axes(handles.axes8);
imshow(t);
title('�Ľ���͸����ͼ');
set(handles.text4,'string','�Ľ���͸����ͼ��ȡ�ɹ�')
%-------------�Ľ�͸���ʽ���----------------------------------------------

%��ԭ������ߣ��õ�����ͼ��
t0=0.1;%͸����������t0
dehaze=zeros(h,w,c);
axes(handles.axes1);
imshow(dehaze);
title('��ԭɫȥ����ͼ��');
save dehaze
set(handles.text4,'string','��ԭɫͼ��ȥ���������')

% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
